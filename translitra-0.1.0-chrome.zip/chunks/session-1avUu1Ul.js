import{a as e,c as t,i as n,n as r,o as i,r as a,s as o,t as s}from"./theme-BzaHie4x.js";var c=[`auto`,`cyr2lat`,`lat2cyr`];function l(){return`
    <div class="toolbar">
      <label class="field">
        <span data-i18n="standard"></span>
        <select id="standard"></select>
      </label>
      <label class="field">
        <span data-i18n="direction"></span>
        <select id="direction"></select>
      </label>
      <span class="spacer"></span>
      <button id="swap" class="icon" data-i18n-title="swap" title="">⇅</button>
    </div>
    <div class="panes">
      <div class="pane">
        <div class="pane-head">
          <span data-i18n="source"></span>
          <button id="clear" class="small" data-i18n="clear"></button>
        </div>
        <textarea id="source" data-i18n-placeholder="sourcePlaceholder" spellcheck="false"></textarea>
      </div>
      <div class="pane">
        <div class="pane-head">
          <span id="result-label" data-i18n="result"></span>
          <button id="copy" class="small primary" data-i18n="copy"></button>
        </div>
        <textarea id="result" readonly></textarea>
      </div>
    </div>
    <p class="hint" id="hint"></p>
    <div class="footer">
      <a href="#" id="open-options" data-i18n="settings"></a>
      <button id="open-window" class="small" data-i18n="openWindow" hidden></button>
    </div>
  `}async function u(u,d){u.innerHTML=l(),r(u);let f=u.querySelector(`#standard`),p=u.querySelector(`#direction`),m=u.querySelector(`#source`),h=u.querySelector(`#result`),g=u.querySelector(`#copy`),_=u.querySelector(`#swap`),v=u.querySelector(`#clear`),y=u.querySelector(`#hint`),b=u.querySelector(`#open-window`),x=u.querySelector(`#open-options`);for(let e of t){let t=document.createElement(`option`);t.value=e,t.textContent=a(`standard_${e}`),f.append(t)}for(let e of c){let t=document.createElement(`option`);t.value=e,t.textContent=a(`direction_${e}`),p.append(t)}let S=await n();s(S.theme),f.value=S.standard,p.value=S.direction;function C(){let{text:e,direction:t}=o(m.value,{standard:f.value,direction:p.value});h.value=e;let n=a(t===`cyr2lat`?`direction_cyr2lat`:`direction_lat2cyr`);y.textContent=m.value.trim()===``?``:t===`lat2cyr`?`${n}. ${a(`reverseApproximate`)}`:n}return m.addEventListener(`input`,C),f.addEventListener(`change`,()=>{i({standard:f.value}),C()}),p.addEventListener(`change`,()=>{i({direction:p.value}),C()}),g.addEventListener(`click`,async()=>{if(!h.value)return;try{await navigator.clipboard.writeText(h.value)}catch{h.select(),document.execCommand(`copy`)}let e=g.textContent;g.textContent=a(`copied`),setTimeout(()=>g.textContent=e,1200)}),_.addEventListener(`click`,()=>{let e=h.value;m.value=e;let t=p.value;t!==`auto`&&(p.value=t===`cyr2lat`?`lat2cyr`:`cyr2lat`),C(),m.focus()}),v.addEventListener(`click`,()=>{m.value=``,C(),m.focus()}),x.addEventListener(`click`,e=>{e.preventDefault(),chrome.runtime.openOptionsPage()}),d.showOpenWindow&&(b.hidden=!1,b.addEventListener(`click`,()=>d.onOpenWindow?.(m.value))),e(e=>{S=e,s(e.theme),f.value!==e.standard&&(f.value=e.standard,C())}),C(),{setSource(e){m.value=e,C()},getSource:()=>m.value,focus:()=>m.focus()}}var d=`pendingText`,f=`converterWindowId`,p=`converterBounds`,m={width:560,height:480};async function h(e){await chrome.storage.session.set({[d]:e})}async function g(){let e=(await chrome.storage.session.get(d))[d];return e!==void 0&&await chrome.storage.session.remove(d),e}async function _(){let e=await chrome.storage.local.get(p);return{...m,...e[p]}}async function v(e){await chrome.storage.local.set({[p]:e})}async function y(e){e!==void 0&&await h(e);let t=(await chrome.storage.session.get(f))[f];if(t!==void 0)try{await chrome.windows.update(t,{focused:!0}),await chrome.runtime.sendMessage({type:`pending-text`}).catch(()=>void 0);return}catch{await chrome.storage.session.remove(f)}let n=await _(),r=await chrome.windows.create({url:chrome.runtime.getURL(`/window.html`),type:`popup`,width:n.width,height:n.height,left:n.left,top:n.top});r?.id!==void 0&&await chrome.storage.session.set({[f]:r.id})}async function b(e){(await chrome.storage.session.get(f))[f]===e&&await chrome.storage.session.remove(f)}export{u as a,g as i,y as n,v as r,b as t};